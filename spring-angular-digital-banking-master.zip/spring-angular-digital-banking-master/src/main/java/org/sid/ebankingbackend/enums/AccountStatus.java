package org.sid.ebankingbackend.enums;

public enum AccountStatus {
    CREATED, ACTIVATED, SUSPENDED
}

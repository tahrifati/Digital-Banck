package org.sid.ebankingbackend.enums;

public enum OperationType {
    DEBIT, CREDIT
}

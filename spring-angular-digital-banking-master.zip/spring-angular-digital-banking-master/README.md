# Spring Angular Digital Banking Project

## App interface        
### main
![main](https://github.com/hatimexe/spring-angular-digital-banking/blob/master/src/main/resources/screens/mainhome.PNG)

### Add customer
![add](https://github.com/hatimexe/spring-angular-digital-banking/blob/master/src/main/resources/screens/added.PNG)

### View &/ delete customers
![view](https://github.com/hatimexe/spring-angular-digital-banking/blob/master/src/main/resources/screens/accounts.PNG)
### Customer data
![data](https://github.com/hatimexe/spring-angular-digital-banking/blob/master/src/main/resources/screens/data.PNG)




## Testing Backend
### API Docs
![API Docs](https://github.com/hatimexe/spring-angular-digital-banking/blob/master/src/main/resources/screens/api-docs.PNG)

### DB Tables
![DB tables](https://github.com/hatimexe/spring-angular-digital-banking/blob/master/src/main/resources/screens/DBtables.PNG)

### Schemas-Swagger-ui
![schemas 1](https://github.com/hatimexe/spring-angular-digital-banking/blob/master/src/main/resources/screens/shemas1.PNG)
![schemas 2](https://github.com/hatimexe/spring-angular-digital-banking/blob/master/src/main/resources/screens/shemas1.PNG)

### In-swagger-ui-operations
![allactions](https://github.com/hatimexe/spring-angular-digital-banking/blob/master/src/main/resources/screens/allactions.PNG)

## Testing Operations

### Adding Customer
![post swagger](https://github.com/hatimexe/spring-angular-digital-banking/blob/master/src/main/resources/screens/testing%20post%20swagger.PNG)

### Confirmation
![customerresultpost](https://github.com/hatimexe/spring-angular-digital-banking/blob/master/src/main/resources/screens/customerresultpost.PNG)

### Deleting Customer by ID
![deleteby id](https://github.com/hatimexe/spring-angular-digital-banking/blob/master/src/main/resources/screens/deletebyid.PNG)

### Confirmation
![deleteresponse](https://github.com/hatimexe/spring-angular-digital-banking/blob/master/src/main/resources/screens/deleteresponse.PNG)

### Account Debit
![accounttdebit](https://github.com/hatimexe/spring-angular-digital-banking/blob/master/src/main/resources/screens/accounttdebit.PNG)

### Confirmation
![accounttdebit](https://github.com/hatimexe/spring-angular-digital-banking/blob/master/src/main/resources/screens/accepteddebit.PNG)

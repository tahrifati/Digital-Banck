package ma.emsi.digitalbankbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DigitalBankBackendApplicationTests {

    @Test
    void contextLoads() {
    }

}

package ma.emsi.digitalbankbackend.enums;

public enum OperationType {
    DEBIT, CREDIT
}

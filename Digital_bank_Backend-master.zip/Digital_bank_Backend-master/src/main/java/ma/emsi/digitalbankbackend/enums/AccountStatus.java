package ma.emsi.digitalbankbackend.enums;

public enum AccountStatus {
    CREATED, ACTIVATED, SUSPENDED
}
